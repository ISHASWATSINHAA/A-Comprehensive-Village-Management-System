﻿namespace village_management
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(login));
            panel7 = new Panel();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            label1 = new Label();
            textBox9 = new TextBox();
            label26 = new Label();
            textBox7 = new TextBox();
            label27 = new Label();
            label28 = new Label();
            linkLabel10 = new LinkLabel();
            button7 = new Button();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            label29 = new Label();
            label30 = new Label();
            label31 = new Label();
            label32 = new Label();
            label33 = new Label();
            panel2 = new Panel();
            label6 = new Label();
            button1 = new Button();
            linkLabel5 = new LinkLabel();
            label5 = new Label();
            linkLabel1 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            button2 = new Button();
            txtPassword = new TextBox();
            txtEmail = new TextBox();
            label4 = new Label();
            label2 = new Label();
            label3 = new Label();
            panel5 = new Panel();
            linkLabel6 = new LinkLabel();
            label18 = new Label();
            linkLabel7 = new LinkLabel();
            button5 = new Button();
            txtpass = new TextBox();
            txtUser = new TextBox();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            panel4 = new Panel();
            linkLabel9 = new LinkLabel();
            label16 = new Label();
            button4 = new Button();
            txtTo = new TextBox();
            label14 = new Label();
            label12 = new Label();
            bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(components);
            panel7.SuspendLayout();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel7
            // 
            panel7.BackColor = Color.LightSteelBlue;
            panel7.Controls.Add(radioButton2);
            panel7.Controls.Add(radioButton1);
            panel7.Controls.Add(label1);
            panel7.Controls.Add(textBox9);
            panel7.Controls.Add(label26);
            panel7.Controls.Add(textBox7);
            panel7.Controls.Add(label27);
            panel7.Controls.Add(label28);
            panel7.Controls.Add(linkLabel10);
            panel7.Controls.Add(button7);
            panel7.Controls.Add(textBox6);
            panel7.Controls.Add(textBox5);
            panel7.Controls.Add(textBox4);
            panel7.Controls.Add(textBox3);
            panel7.Controls.Add(label29);
            panel7.Controls.Add(label30);
            panel7.Controls.Add(label31);
            panel7.Controls.Add(label32);
            panel7.Controls.Add(label33);
            panel7.Font = new Font("Microsoft Sans Serif", 12F);
            panel7.Location = new Point(1, 2);
            panel7.Margin = new Padding(2);
            panel7.Name = "panel7";
            panel7.Size = new Size(441, 732);
            panel7.TabIndex = 15;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Century Gothic", 9F);
            radioButton2.Location = new Point(299, 515);
            radioButton2.Margin = new Padding(2);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(104, 25);
            radioButton2.TabIndex = 18;
            radioButton2.TabStop = true;
            radioButton2.Text = "FEMALE";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Century Gothic", 9F);
            radioButton1.Location = new Point(199, 515);
            radioButton1.Margin = new Padding(2);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(85, 25);
            radioButton1.TabIndex = 17;
            radioButton1.TabStop = true;
            radioButton1.Text = "MALE";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F);
            label1.Location = new Point(46, 518);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(88, 21);
            label1.TabIndex = 16;
            label1.Text = "Gender :";
            // 
            // textBox9
            // 
            textBox9.BorderStyle = BorderStyle.None;
            textBox9.Font = new Font("Myanmar Text", 8F);
            textBox9.Location = new Point(198, 460);
            textBox9.Margin = new Padding(2);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(201, 30);
            textBox9.TabIndex = 15;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Century Gothic", 9F);
            label26.Location = new Point(46, 460);
            label26.Margin = new Padding(2, 0, 2, 0);
            label26.Name = "label26";
            label26.Size = new Size(100, 21);
            label26.TabIndex = 14;
            label26.Text = "Password :";
            // 
            // textBox7
            // 
            textBox7.BorderStyle = BorderStyle.None;
            textBox7.Font = new Font("Myanmar Text", 8F);
            textBox7.Location = new Point(196, 408);
            textBox7.Margin = new Padding(2);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(201, 30);
            textBox7.TabIndex = 13;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Century Gothic", 9F);
            label27.Location = new Point(46, 410);
            label27.Margin = new Padding(2, 0, 2, 0);
            label27.Name = "label27";
            label27.Size = new Size(77, 21);
            label27.TabIndex = 12;
            label27.Text = "Phone :";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Century Gothic", 8.25F);
            label28.Location = new Point(68, 665);
            label28.Margin = new Padding(2, 0, 2, 0);
            label28.Name = "label28";
            label28.Size = new Size(238, 21);
            label28.TabIndex = 11;
            label28.Text = "Already have an Account?";
            // 
            // linkLabel10
            // 
            linkLabel10.AutoSize = true;
            linkLabel10.Font = new Font("Century Gothic", 8.25F);
            linkLabel10.Location = new Point(304, 665);
            linkLabel10.Margin = new Padding(2, 0, 2, 0);
            linkLabel10.Name = "linkLabel10";
            linkLabel10.Size = new Size(58, 21);
            linkLabel10.TabIndex = 10;
            linkLabel10.TabStop = true;
            linkLabel10.Text = "Login ";
            linkLabel10.LinkClicked += linkLabel10_LinkClicked;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.HotTrack;
            button7.FlatStyle = FlatStyle.Popup;
            button7.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.White;
            button7.Location = new Point(161, 580);
            button7.Margin = new Padding(2);
            button7.Name = "button7";
            button7.Size = new Size(120, 50);
            button7.TabIndex = 9;
            button7.Text = "SUBMIT";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // textBox6
            // 
            textBox6.BorderStyle = BorderStyle.None;
            textBox6.Font = new Font("Myanmar Text", 8F);
            textBox6.Location = new Point(196, 352);
            textBox6.Margin = new Padding(2);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(201, 30);
            textBox6.TabIndex = 8;
            // 
            // textBox5
            // 
            textBox5.BorderStyle = BorderStyle.None;
            textBox5.Font = new Font("Myanmar Text", 8F);
            textBox5.Location = new Point(196, 302);
            textBox5.Margin = new Padding(2);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(201, 30);
            textBox5.TabIndex = 7;
            // 
            // textBox4
            // 
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Font = new Font("Myanmar Text", 8F);
            textBox4.Location = new Point(196, 248);
            textBox4.Margin = new Padding(2);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(201, 30);
            textBox4.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Myanmar Text", 8F);
            textBox3.Location = new Point(196, 188);
            textBox3.Margin = new Padding(2);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(201, 30);
            textBox3.TabIndex = 5;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Century Gothic", 9F);
            label29.Location = new Point(46, 360);
            label29.Margin = new Padding(2, 0, 2, 0);
            label29.Name = "label29";
            label29.Size = new Size(78, 21);
            label29.TabIndex = 4;
            label29.Text = "User Id :";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Font = new Font("Century Gothic", 9F);
            label30.Location = new Point(46, 302);
            label30.Margin = new Padding(2, 0, 2, 0);
            label30.Name = "label30";
            label30.Size = new Size(99, 21);
            label30.TabIndex = 3;
            label30.Text = "House No:";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Font = new Font("Century Gothic", 9F);
            label31.Location = new Point(46, 248);
            label31.Margin = new Padding(2, 0, 2, 0);
            label31.Name = "label31";
            label31.Size = new Size(65, 21);
            label31.TabIndex = 2;
            label31.Text = "Email :";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Font = new Font("Century Gothic", 9F);
            label32.Location = new Point(46, 190);
            label32.Margin = new Padding(2, 0, 2, 0);
            label32.Name = "label32";
            label32.Size = new Size(74, 21);
            label32.TabIndex = 1;
            label32.Text = "Name :";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Cursor = Cursors.IBeam;
            label33.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label33.Location = new Point(119, 102);
            label33.Margin = new Padding(2, 0, 2, 0);
            label33.Name = "label33";
            label33.Size = new Size(235, 38);
            label33.TabIndex = 0;
            label33.Text = "REGISTRATION";
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel2.BackColor = Color.LightSteelBlue;
            panel2.Controls.Add(label6);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(linkLabel5);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(linkLabel1);
            panel2.Controls.Add(linkLabel2);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(txtPassword);
            panel2.Controls.Add(txtEmail);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label3);
            panel2.Font = new Font("Microsoft Sans Serif", 12F);
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(2);
            panel2.Name = "panel2";
            panel2.Size = new Size(441, 732);
            panel2.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Century Gothic", 9F);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(54, 538);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(229, 21);
            label6.TabIndex = 11;
            label6.Text = "Don't have an account?";
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.BackColor = Color.Transparent;
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Zoom;
            button1.FlatAppearance.BorderColor = Color.FromArgb(10, 18, 80);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(391, 2);
            button1.Margin = new Padding(2);
            button1.Name = "button1";
            button1.Size = new Size(38, 42);
            button1.TabIndex = 10;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // linkLabel5
            // 
            linkLabel5.AutoSize = true;
            linkLabel5.Font = new Font("Century Gothic", 10F);
            linkLabel5.ForeColor = SystemColors.ButtonHighlight;
            linkLabel5.Location = new Point(162, 688);
            linkLabel5.Margin = new Padding(2, 0, 2, 0);
            linkLabel5.Name = "linkLabel5";
            linkLabel5.Size = new Size(77, 23);
            linkLabel5.TabIndex = 9;
            linkLabel5.TabStop = true;
            linkLabel5.Text = "ADMIN";
            linkLabel5.LinkClicked += linkLabel5_LinkClicked;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(118, 128);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(200, 38);
            label5.TabIndex = 8;
            label5.Text = "USER LOGIN";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel1.ForeColor = SystemColors.ButtonHighlight;
            linkLabel1.LinkColor = Color.Black;
            linkLabel1.Location = new Point(66, 412);
            linkLabel1.Margin = new Padding(2, 0, 2, 0);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(152, 21);
            linkLabel1.TabIndex = 3;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Forgot Password";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.Font = new Font("Century Gothic", 9F);
            linkLabel2.ForeColor = SystemColors.ButtonHighlight;
            linkLabel2.Location = new Point(278, 538);
            linkLabel2.Margin = new Padding(2, 0, 2, 0);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(117, 21);
            linkLabel2.TabIndex = 4;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Create one!";
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.HotTrack;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(162, 472);
            button2.Margin = new Padding(2);
            button2.Name = "button2";
            button2.Size = new Size(149, 52);
            button2.TabIndex = 2;
            button2.Text = "LOGIN";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.White;
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.ForeColor = SystemColors.ActiveCaptionText;
            txtPassword.Location = new Point(66, 365);
            txtPassword.Margin = new Padding(2);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(318, 28);
            txtPassword.TabIndex = 7;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.White;
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.ForeColor = SystemColors.ActiveCaptionText;
            txtEmail.Location = new Point(66, 285);
            txtEmail.Margin = new Padding(2);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(318, 28);
            txtEmail.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Century Gothic", 9F);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(66, 332);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(90, 21);
            label4.TabIndex = 5;
            label4.Text = "Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(154, -38);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(79, 29);
            label2.TabIndex = 3;
            label2.Text = "label2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Century Gothic", 9F);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(66, 252);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(105, 21);
            label3.TabIndex = 4;
            label3.Text = "User Name";
            // 
            // panel5
            // 
            panel5.BackColor = Color.LightSteelBlue;
            panel5.Controls.Add(linkLabel6);
            panel5.Controls.Add(label18);
            panel5.Controls.Add(linkLabel7);
            panel5.Controls.Add(button5);
            panel5.Controls.Add(txtpass);
            panel5.Controls.Add(txtUser);
            panel5.Controls.Add(label19);
            panel5.Controls.Add(label20);
            panel5.Controls.Add(label21);
            panel5.Font = new Font("Microsoft Sans Serif", 12F);
            panel5.Location = new Point(0, 0);
            panel5.Margin = new Padding(2);
            panel5.Name = "panel5";
            panel5.Size = new Size(441, 732);
            panel5.TabIndex = 14;
            // 
            // linkLabel6
            // 
            linkLabel6.AutoSize = true;
            linkLabel6.Font = new Font("Century Gothic", 10F);
            linkLabel6.ForeColor = SystemColors.ButtonHighlight;
            linkLabel6.Location = new Point(198, 688);
            linkLabel6.Margin = new Padding(2, 0, 2, 0);
            linkLabel6.Name = "linkLabel6";
            linkLabel6.Size = new Size(56, 23);
            linkLabel6.TabIndex = 9;
            linkLabel6.TabStop = true;
            linkLabel6.Text = "USER";
            linkLabel6.LinkClicked += linkLabel6_LinkClicked;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(120, 128);
            label18.Margin = new Padding(2, 0, 2, 0);
            label18.Name = "label18";
            label18.Size = new Size(235, 38);
            label18.TabIndex = 8;
            label18.Text = "ADMIN LOGIN";
            // 
            // linkLabel7
            // 
            linkLabel7.AutoSize = true;
            linkLabel7.Font = new Font("Century Gothic", 9F);
            linkLabel7.ForeColor = SystemColors.ButtonHighlight;
            linkLabel7.LinkColor = Color.Black;
            linkLabel7.Location = new Point(66, 412);
            linkLabel7.Margin = new Padding(2, 0, 2, 0);
            linkLabel7.Name = "linkLabel7";
            linkLabel7.Size = new Size(152, 21);
            linkLabel7.TabIndex = 3;
            linkLabel7.TabStop = true;
            linkLabel7.Text = "Forgot Password";
            // 
            // button5
            // 
            button5.BackColor = SystemColors.HotTrack;
            button5.FlatStyle = FlatStyle.Popup;
            button5.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.ForeColor = SystemColors.ButtonHighlight;
            button5.Location = new Point(162, 472);
            button5.Margin = new Padding(2);
            button5.Name = "button5";
            button5.Size = new Size(149, 52);
            button5.TabIndex = 2;
            button5.Text = "LOGIN";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // txtpass
            // 
            txtpass.BackColor = Color.White;
            txtpass.BorderStyle = BorderStyle.None;
            txtpass.ForeColor = SystemColors.ActiveCaptionText;
            txtpass.Location = new Point(66, 365);
            txtpass.Margin = new Padding(2);
            txtpass.Name = "txtpass";
            txtpass.Size = new Size(318, 28);
            txtpass.TabIndex = 7;
            // 
            // txtUser
            // 
            txtUser.BackColor = Color.White;
            txtUser.BorderStyle = BorderStyle.None;
            txtUser.ForeColor = SystemColors.ActiveCaptionText;
            txtUser.Location = new Point(66, 285);
            txtUser.Margin = new Padding(2);
            txtUser.Name = "txtUser";
            txtUser.Size = new Size(318, 28);
            txtUser.TabIndex = 6;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Transparent;
            label19.Font = new Font("Century Gothic", 9F);
            label19.ForeColor = SystemColors.ActiveCaptionText;
            label19.Location = new Point(66, 332);
            label19.Margin = new Padding(2, 0, 2, 0);
            label19.Name = "label19";
            label19.Size = new Size(90, 21);
            label19.TabIndex = 5;
            label19.Text = "Password";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(154, -38);
            label20.Margin = new Padding(2, 0, 2, 0);
            label20.Name = "label20";
            label20.Size = new Size(92, 29);
            label20.TabIndex = 3;
            label20.Text = "label20";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = Color.Transparent;
            label21.Font = new Font("Century Gothic", 9F);
            label21.ForeColor = SystemColors.ActiveCaptionText;
            label21.Location = new Point(66, 252);
            label21.Margin = new Padding(2, 0, 2, 0);
            label21.Name = "label21";
            label21.Size = new Size(105, 21);
            label21.TabIndex = 4;
            label21.Text = "User Name";
            // 
            // panel4
            // 
            panel4.BackColor = Color.LightSteelBlue;
            panel4.Controls.Add(linkLabel9);
            panel4.Controls.Add(label16);
            panel4.Controls.Add(button4);
            panel4.Controls.Add(txtTo);
            panel4.Controls.Add(label14);
            panel4.Controls.Add(label12);
            panel4.Font = new Font("Microsoft Sans Serif", 12F);
            panel4.Location = new Point(0, 0);
            panel4.Margin = new Padding(2);
            panel4.Name = "panel4";
            panel4.Size = new Size(441, 732);
            panel4.TabIndex = 13;
            // 
            // linkLabel9
            // 
            linkLabel9.AutoSize = true;
            linkLabel9.Font = new Font("Century Gothic", 8.25F);
            linkLabel9.Location = new Point(288, 432);
            linkLabel9.Margin = new Padding(2, 0, 2, 0);
            linkLabel9.Name = "linkLabel9";
            linkLabel9.Size = new Size(95, 21);
            linkLabel9.TabIndex = 16;
            linkLabel9.TabStop = true;
            linkLabel9.Text = "Login here";
            linkLabel9.LinkClicked += linkLabel9_LinkClicked;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Century Gothic", 8.25F);
            label16.ForeColor = SystemColors.ActiveCaptionText;
            label16.Location = new Point(60, 432);
            label16.Margin = new Padding(2, 0, 2, 0);
            label16.Name = "label16";
            label16.Size = new Size(235, 21);
            label16.TabIndex = 15;
            label16.Text = "Remember Your Password?";
            // 
            // button4
            // 
            button4.BackColor = SystemColors.HotTrack;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Century Gothic", 9F);
            button4.ForeColor = SystemColors.ButtonHighlight;
            button4.Location = new Point(156, 538);
            button4.Margin = new Padding(2);
            button4.Name = "button4";
            button4.Size = new Size(149, 52);
            button4.TabIndex = 10;
            button4.Text = "Submit";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // txtTo
            // 
            txtTo.BackColor = Color.White;
            txtTo.BorderStyle = BorderStyle.None;
            txtTo.ForeColor = SystemColors.ActiveCaptionText;
            txtTo.Location = new Point(71, 320);
            txtTo.Margin = new Padding(2);
            txtTo.Name = "txtTo";
            txtTo.Size = new Size(318, 28);
            txtTo.TabIndex = 14;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Century Gothic", 9F);
            label14.ForeColor = SystemColors.ActiveCaptionText;
            label14.Location = new Point(71, 288);
            label14.Margin = new Padding(2, 0, 2, 0);
            label14.Name = "label14";
            label14.Size = new Size(130, 21);
            label14.TabIndex = 12;
            label14.Text = "Email Address";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(81, 168);
            label12.Margin = new Padding(2, 0, 2, 0);
            label12.Name = "label12";
            label12.Size = new Size(327, 38);
            label12.TabIndex = 9;
            label12.Text = "FORGOT PASSWORD";
            // 
            // bunifuElipse1
            // 
            bunifuElipse1.ElipseRadius = 20;
            bunifuElipse1.TargetControl = this;
            // 
            // login
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(441, 732);
            Controls.Add(panel2);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel7);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Village management System";
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel7;
        private TextBox textBox9;
        private Label label26;
        private TextBox textBox7;
        private Label label27;
        private Label label28;
        private LinkLabel linkLabel10;
        private Button button7;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private Label label29;
        private Label label30;
        private Label label31;
        private Label label32;
        private Label label33;
        private Panel panel2;
        private LinkLabel linkLabel5;
        private Label label5;
        private LinkLabel linkLabel1;
        private LinkLabel linkLabel2;
        private Button button2;
        private TextBox txtPassword;
        private TextBox txtEmail;
        private Label label4;
        private Label label2;
        private Label label3;
        private Panel panel5;
        private LinkLabel linkLabel6;
        private Label label18;
        private LinkLabel linkLabel7;
        private Button button5;
        private TextBox txtpass;
        private TextBox txtUser;
        private Label label19;
        private Label label20;
        private Label label21;
        private Panel panel4;
        private LinkLabel linkLabel9;
        private Label label16;
        private Button button4;
        private TextBox txtTo;
        private Label label14;
        private Label label12;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private Label label1;
        private Button button1;
        private Label label6;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
    }
}